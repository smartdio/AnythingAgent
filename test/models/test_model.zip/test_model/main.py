from typing import List, Dict, Optional, Callable, Awaitable
from app.models.base import AnythingBaseModel

class TestModel(AnythingBaseModel):
    """
    测试模型
    这是一个用于测试模型部署机制的简单模型。
    它支持基本的消息处理和流式输出。
    """
    
    async def on_chat_start(self) -> None:
        """聊天开始时的处理"""
        self.clear_context()
        self.set_context("messages_count", 0)
    
    async def on_chat_messages(
        self,
        messages: List[Dict[str, str]],
        callback: Optional[Callable[[str], Awaitable[None]]] = None
    ) -> Optional[str]:
        """
        处理聊天消息
        
        支持两种模式：
        1. 普通模式：直接返回完整响应
        2. 流式模式：通过callback分段发送响应
        """
        # 获取配置参数
        parameters = self.config.get("parameters", {})
        temperature = parameters.get("temperature", 0.7)
        max_tokens = parameters.get("max_tokens", 100)
        top_p = parameters.get("top_p", 1.0)
        
        # 更新消息计数
        count = self.get_context("messages_count", 0) + 1
        self.set_context("messages_count", count)
        
        # 获取最后一条用户消息
        last_message = None
        for msg in reversed(messages):
            if msg["role"] == "user":
                last_message = msg["content"]
                break
        
        if not last_message:
            response = "未找到用户消息"
            if callback:
                await callback(response)
                return None
            return response
        
        # 构建响应
        responses = [
            f"[测试模型 v{self.config.get('version', '1.0.0')}]\n",
            f"配置：temperature={temperature}, max_tokens={max_tokens}, top_p={top_p}\n",
            f"这是第 {count} 条消息\n",
            f"收到消息：{last_message}\n"
        ]
        
        # 读取词表文件（如果存在）
        vocab_file = self.data_dir / "vocab.txt"
        if vocab_file.exists():
            vocab = vocab_file.read_text().strip()
            responses.append(f"词表大小：{len(vocab.split())}\n")
        
        if callback:
            # 流式模式：逐行发送
            for response in responses:
                await callback(response)
            return None
        else:
            # 普通模式：返回完整响应
            return "".join(responses)
    
    async def on_chat_end(self) -> None:
        """聊天结束时的处理"""
        self.clear_context() 